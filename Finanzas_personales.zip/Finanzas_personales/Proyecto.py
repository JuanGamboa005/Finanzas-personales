from flask import Flask
from datetime import datetime
from proyectoU import Persona
import json
import unittest

#Se almacena la informacion en el Json

def to_json(nombre, mes, historial):
    # Data to be written
    dictionary = {
        "Nombre": nombre,
        "Mes": mes,
        "sueldo fijo": Persona.sueldo_ini,
    }
    dictionary.update(historial)
    # Serializing json
    json_object = json.dumps(dictionary, indent=4)
    
    # Writing to sample.json
    with open("sample.json", "w") as outfile:
        outfile.write(json_object)
 
def main():
    menu()

    #definicion de variables

    saldo = Persona.sueldo_ini
    historial_transacciones = {}
    opcion = 1
    opcion_fijo = 1

    #pregunta al usuario los gastos fijos

    while opcion_fijo!=0:
        opcion = int(input("De cuanto son sus gastos fijos: "))
        Persona.gastos_fijos = opcion
        if Persona.gastos_fijos > saldo:
            print("Su saldo no es suficiente ")
            opcion_fijo = 1
            saldo_suficiente = False
            opcion = 0
        else:
            saldo = saldo - Persona.gastos_fijos
            historial_transacciones["Gasto fijo: "]=Persona.gastos_fijos
            saldo_suficiente = True
            opcion_fijo = 0

    #variables      

    while opcion!=0:
        try:
            opcion = (input(" Tiene gastos variables (ingrese si o no): "))
            if opcion.lower().strip() == "si":
                opcion = (input("Que tipo de gasto es: "))
                opcion2 = int(input("Cual es el valor del gasto: "))
                if opcion2 > saldo:
                    print("Su saldo no es suficiente ")
                else:
                    saldo = saldo - opcion2 
                    historial_transacciones[opcion]=opcion2
                
            elif opcion.lower().strip() == "no":
                break       
                                         
        except ValueError:
            print("opcion no valida")

    #Al principio se escribe informacion en el archivo Json 

    to_json(Persona.nombre, Persona.mes ,historial_transacciones)
    if saldo_suficiente == True:
        print("tu saldo sobrante a fin de mes es: ",porcentaje_saldo(Persona.sueldo_ini,saldo),"%")
    

    #Dependiendo del % sobrante, dar unas recomendaciones financieras al usuario 

    variable_porcentaje = porcentaje_saldo(Persona.sueldo_ini,saldo)

    if variable_porcentaje >= 50:
        print("Usted tiene una buena economía. Le recomendamos ahorrar al menos el 20% de su salario para construir un fondo de emergencia y considerar invertir parte de sus ahorros en un portafolio diversificado de acciones, fondos mutuos o ETFs a largo plazo.")
    elif variable_porcentaje >= 30 and variable_porcentaje < 50:
        print("Usted puede mejorar su economía. Le recomendamos ahorrar al menos el 10% de su salario para emergencias y priorizar el pago de deudas con tasas de interés más altas.")
    elif variable_porcentaje < 30:
        print("Usted necesita mejorar su economía. Le recomendamos buscar maneras de reducir sus gastos y considerar formas de aumentar sus ingresos. También, intente ahorrar al menos el 5% de su salario.")

#se calcula el porcentaje sobrante a fin de mes                    

def porcentaje_saldo(saldo_inicial,saldo_final):
    resultado =(saldo_final * 100)/saldo_inicial 
    return resultado

#Se esta recibiendo la información del usuario, ya sea como, cual es su nombre, sueldo neto mensual y en que mes se encuentra

def menu():
    opcion = (input("Ingrese el nombre de la persona: "))
    Persona.nombre = opcion

    opcion = int(input("Ingrese el Sueldo de la persona: "))
    Persona.sueldo_ini = opcion

    opcion = int(input("Ingrese el mes en que se encuentra: "))
    Persona.mes = opcion #numero entero

    mes_string = fecha(Persona.mes) #mes en palabra
    
    print(mes_string)

#Convierte el mes de numero a palabras, ej. (si el usuario escribe 4, se va a guardar como Abril)

def fecha(fecha):
    fecha_a_mes = {
    1: "enero",
    2: "febrero",
    3: "marzo",
    4: "abril",
    5: "mayo",
    6: "junio",
    7: "julio",
    8: "agosto",
    9: "septiembre",
    10: "octubre",
    11: "noviembre",
    12: "diciembre"
    }
    mes = None

    #Buscamos el mes en el diccionario
    if isinstance(fecha, int) and fecha in fecha_a_mes:
        mes = fecha_a_mes[fecha]
    elif isinstance(fecha, str):
        # Convertimos a minúsculas para hacer la búsqueda
        fecha = fecha.lower()
        # Buscamos el mes en el diccionario
        for key, value in fecha_a_mes.items():
            if value == fecha:
                mes = value
                break
    if mes:
        return mes
    else:
        return "Mes no valido"
    
#Prueba Unitaria (fecha)

class TestBasico(unittest.TestCase):
    def test(self):
        print("prueba unitaria para fecha")
        self.assertEqual(fecha(1), "enero", "Error")

#Ruta de ejecucion para flask

app = Flask(__name__)

@app.route('/')
def Index():
    with open('sample.json', 'r') as openfile:
        # Reading from json file
        json_object = json.load(openfile)
 
    print(json_object)
    return json_object

if __name__ == "__main__":
    main()
    app.run(port = 3000, debug = False)
    unittest.main()