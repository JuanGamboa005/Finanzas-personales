class Persona:
    sueldo_ini = 0
    nombre = ""
    mes = 0
    gastos_fijos = 0
    def __init__(self): 
        self.print
    

class Gasto_fijo:
    valor_gasto = 0
    def __init__(self):
        self.print
        

class Gasto_var: 
    valor_var = 0
    def __init__(self):
        self.print
        
